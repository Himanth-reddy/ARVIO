ARVIO — media kit

ARVIO is a free, open-source media app for Android and Android TV, with a browser version. Connect your own sources, organise watchlists and home-server libraries, and browse live TV with an electronic programme guide. Supported integrations include Jellyfin, Plex, Emby, Trakt and Simkl.

The Android APK is free. ARVIO Web can be self-hosted for free. Optional Premium managed hosting is $2.99/month and helps fund hosting and development. Media, IPTV subscriptions and third-party services are not included. Browser playback depends on the source, codec, device and network.

Website: https://arvio.tv/
APK and source: https://github.com/ProdigyV21/ARVIO
Setup guides: https://arvio.tv/guides/
Premium: https://arvio.tv/premium/
Membership: https://ko-fi.com/arvio/tiers
Community: https://discord.gg/UavuEYMfQ4

These are existing ARVIO 2.0 screenshots, not new renders. Third-party artwork and trademarks belong to their respective owners. Use screenshots to illustrate ARVIO; do not imply that the displayed content is included.
